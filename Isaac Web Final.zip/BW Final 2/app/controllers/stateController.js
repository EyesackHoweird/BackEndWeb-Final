const State = require('../models/State.js');

const data = {
    states: require("../models/states.json"),
    setStates(data){
        this.states = data;
    }
}

// Retrieve and return all States from database

const getAllStates = async(req,res) => {
    let output = [];
    const states = await State.find().exec();
    data.states.forEach((state) =>{
    if(req.query.contig === 'true' && state.code == "AK" && state.code == "HI"){
        return;
    }
    if(req.query.contig === 'false' && !(state.code == "AK" && state.code == "HI")){
        return;
    }

    const statefacts = states.find( x => x.stateCode == states.code);
        if(statefacts) output.push({...state, funfacts: statefacts.funfacts});
        else output.push(state);
    })
    res.json(output);

}

const getState = async(req,res) =>{
    const state = require('../models/states.json').find((s) => s.code === req.params.state);

    // State does not exist, 404 error
    if(!state) {
        res.status(404).send(`State ${req.params.state} not found`);
        return;
    }

    const stateWithFacts = await State.findOne({code: req.params.state});

    // If found, present random fun fact
    if(stateWithFacts){
        state.funfact = stateWithFacts.funfacts[Math.floor(Math.random() * stateWithFacts.funfacts.length)];
    }

    // Send state object as response
    res.json(state);
}

const getStateCapital = (req, res) =>{
    const state = require('../models/states.json').find((s)=> s.code === req.params.state);

    if(!state){
        res.status(404).send(`State ${req.params.state} not found`);
        return;
    }

    const capitalObject = { state: state.name, capital: state.capital};
    res.json(capitalObject);
}

const getStatePopulation = (req, res) =>{
    const state = require('../models/states.json').find((s)=> s.code === req.params.state);

    if(!state){
        res.status(404).send(`State ${req.params.state} not found`);
        return;
    }

    const populationObject = { state: state.name, population: state.population};
    res.json(populationObject);
}

const getStateNickname = (req, res) =>{
    const state = require('../models/states.json').find((s)=> s.code === req.params.state);

    if(!state){
        res.status(404).send(`State ${req.params.state} not found`);
        return;
    }

    const nickObject = { state: state.name, nickname: state.nickname};
    res.json(nickObject);
}

const getStateAdmission = (req, res) =>{
    const state = require('../models/states.json').find((s)=> s.code === req.params.state);

    if(!state){
        res.status(404).send(`State ${req.params.state} not found`);
        return;
    }

    const admObject = { state: state.name, admission_date: state.admission_date, admission_number: state.admission_number};
    res.json(admObject);
}

const getFact = async(req,res) => {
    // Finds the state with the specified code in the State model
    const stateWithFunFacts = await State.findOne({ code: req.params.state });
    // If no state is found or if there are no fun facts for the state, return a 404 error
    if (!stateWithFunFacts || stateWithFunFacts.funfacts.length === 0) {
        res.status(404).send(`No fun facts found for state ${req.params.state}`);
        return;
    }
    // Picks a random fun fact for the state from the list of fun facts
    const funFact = stateWithFunFacts.funfacts[Math.floor(Math.random() * stateWithFunFacts.funfacts.length)];
    // Sends the fun fact as a JSON response
    res.json(funFact);
}

const addFact = async(req,res) =>{
    try {
        const { state } = req.params;
        const { funfacts } = req.body;
    
        if (!funfacts || !Array.isArray(funfacts)) {
          return res.status(400).json({ message: 'Invalid request body' });
        }
    
        const stateData = await State.findOne({ stateCode: state });
    
        if (!stateData) {
          const newStateData = new State({ stateCode: state, funfacts });
          await newStateData.save();
          return res.status(201).json(newStateData);
        }
    
        stateData.funfacts = [...stateData.funfacts, ...funfacts];
        await stateData.save();
    
        return res.status(200).json(stateData);
      } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Internal server error' });
      }
}

const updateFact = async(req,res) =>{
    try {
        const { state } = req.params;
        const { index, funfact } = req.body;
    
        if (!index || !funfact) {
          return res.status(400).json({ message: 'Invalid request body' });
        }
    
        const stateData = await State.findOne({ stateCode: state });
    
        if (!stateData || stateData.funfacts.length === 0 || stateData.funfacts.length < index) {
          return res.status(404).json({ message: 'Fun fact not found' });
        }
    
        stateData.funfacts[index - 1] = funfact;
        await stateData.save();
    
        return res.status(200).json(stateData);
      } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Internal server error' });
      }
}

const deleteFact = async(req,res) =>{
    try {
        const { state } = req.params;
        const { index } = req.body;
    
        if (!index) {
          return res.status(400).json({ message: 'Invalid request body' });
        }
    
        const stateData = await State.findOne({ stateCode: state });
    
        if (!stateData || stateData.funfacts.length === 0 || stateData.funfacts.length < index) {
          return res.status(404).json({ message: 'Fun fact not found' });
        }
    
        stateData.funfacts = stateData.funfacts.filter((_, i) => i !== index - 1);
        await stateData.save();
    
        return res.status(200).json(stateData);
      } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Internal server error' });
      }
}

module.exports = {
    getAllStates,
    getState,
    getFact,
    getStateCapital,
    getStateNickname,
    getStatePopulation,
    getStateAdmission,
    updateFact,
    addFact,
    deleteFact
}

