const express = require("express");
const router = express();
const stateController = require("../controllers/stateController");

router.route("/").get(stateController.getAllStates);
router.route("/:id").get(stateController.getState);
router.route("/:id/capital").get(stateController.getStateCapital);
router.route("/:id/admission").get(stateController.getStateAdmission);
router.route("/:id/population").get(stateController.getStatePopulation);
router.route("/:id/nickname").get(stateController.getStateNickname);


router.route("/:id/funfact").get(stateController.getFact)
.post(stateController.addFact)
.delete(stateController.deleteFact)
.patch(stateController.updateFact);

module.exports = router;