require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');

// create express app
const app = express();

// parse requests of application urlencoded
app.use(bodyParser.urlencoded({extended: true}));

// parse requests of application/json
app.use(bodyParser.json());

//Configuring database
const mongoose = require('mongoose');
const connectDB = require('./config/dbConfig');
//Connect to database


/*mongoose.connect(dbConfig.url, {
    useNewUrlParser: true
}).then(()=>{
    console.log("Successfully connected to the database");
}).catch(err=>{
    console.log("Couldn't connect to the database. Exiting now...", err);
    process.exit();
});
*/

connectDB;

//simple route
app.get('/', (req,res)=>{
    res.json({"message": "Welcome to States Fun Facts, where you can learn neat things about the US!"});
});

app.use("/states", require("./app/routes/routes"));

//require('./app/routes/routes.js')(app);

app.listen(3000, ()=>{
    console.log("Server is listening on port 3000");
});